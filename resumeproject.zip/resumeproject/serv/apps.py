from django.apps import AppConfig


class ServConfig(AppConfig):
    name = 'serv'
